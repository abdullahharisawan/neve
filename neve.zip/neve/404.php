<?php
/**
 * 404 template.
 *
 * @package Neve
 */

get_header();
do_action( 'neve_do_404' );
get_footer();
